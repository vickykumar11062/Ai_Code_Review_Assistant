import os
import sys
import requests
from github import Github
import openai

# Set up OpenAI API
openai.api_key = os.environ.get("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")

# Set up GitHub API
github_token = os.environ.get("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")
github_client = Github(github_token)

def fetch_pull_request(repo_name, pr_number):
    """Fetch a pull request by number from a specified repository."""
    try:
        repo = github_client.get_repo(repo_name)
        pull_request = repo.get_pull(pr_number)
        return pull_request
    except Exception as e:
        print(f"Error fetching pull request: {e}")
        sys.exit(1)

def get_changed_files(pull_request):
    """Get the files changed in a pull request."""
    files = []
    for file in pull_request.get_files():
        if file.filename.endswith(('.py', '.js', '.java', '.cpp', '.ts')):  # Add more extensions as needed
            files.append({
                'filename': file.filename,
                'patch': file.patch if file.patch else "",
                'status': file.status,
                'additions': file.additions,
                'deletions': file.deletions,
                'raw_url': file.raw_url
            })
    return files

def download_file_content(url):
    """Download the content of a file from GitHub."""
    headers = {"Authorization": f"token {github_token}"}
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        return response.text
    return None

def analyze_code_changes(files):
    """Use AI to analyze code changes."""
    results = []
    
    for file in files:
        if file['patch']:
            # For larger files, you might need to break this down or use a different approach
            prompt = f"""
            As an expert code reviewer, analyze the following code changes and provide feedback:
            
            Filename: {file['filename']}
            Changes:
            ```
            {file['patch']}
            ```
            
            Consider:
            1. Code quality and readability
            2. Potential bugs or logic errors
            3. Adherence to best practices
            4. Performance issues
            5. Security concerns
            
            Format your response as:
            - Issues: [list any issues found]
            - Suggestions: [list improvement suggestions]
            - Verdict: ["approve" or "request changes"]
            - Reasoning: [brief explanation for verdict]
            """
            
            try:
                response = openai.ChatCompletion.create(
                    model="gpt-4",  # You can use gpt-3.5-turbo for a less expensive option
                    messages=[
                        {"role": "system", "content": "You are an expert code reviewer who analyzes code changes and provides detailed feedback."},
                        {"role": "user", "content": prompt}
                    ],
                    temperature=0.3,
                    max_tokens=1000
                )
                
                review = response.choices[0].message.content
                results.append({
                    'filename': file['filename'],
                    'review': review
                })
            except Exception as e:
                results.append({
                    'filename': file['filename'],
                    'review': f"Error analyzing code: {str(e)}"
                })
    
    return results

def aggregate_results(reviews):
    """Aggregate the results of all file reviews and provide an overall verdict."""
    request_changes = any("request changes" in review['review'].lower() for review in reviews)
    
    overall_verdict = "REQUEST CHANGES" if request_changes else "APPROVE"
    
    return {
        'verdict': overall_verdict,
        'file_reviews': reviews
    }

def post_review_comment(pull_request, review_result):
    """Post the review as a comment on the pull request."""
    comment = f"# AI Code Review: {review_result['verdict']}\n\n"
    
    for file_review in review_result['file_reviews']:
        comment += f"## {file_review['filename']}\n\n"
        comment += f"{file_review['review']}\n\n"
    
    try:
        pull_request.create_issue_comment(comment)
        print(f"Posted review comment to PR #{pull_request.number}")
    except Exception as e:
        print(f"Error posting comment: {e}")

def main():
    if len(sys.argv) != 3:
        print("Usage: python code_review.py <repo_name> <pr_number>")
        print("Example: python code_review.py 'username/repo' 123")
        sys.exit(1)
    
    repo_name = sys.argv[1]
    pr_number = int(sys.argv[2])
    
    print(f"Analyzing PR #{pr_number} in repository {repo_name}...")
    
    # Fetch the pull request
    pull_request = fetch_pull_request(repo_name, pr_number)
    
    # Get the changed files
    files = get_changed_files(pull_request)
    print(f"Found {len(files)} relevant files to review")
    
    # Analyze the code changes
    reviews = analyze_code_changes(files)
    
    # Aggregate the results
    result = aggregate_results(reviews)
    
    # Print the verdict
    print(f"Review verdict: {result['verdict']}")
    
    # Post the review as a comment
    if os.environ.get("POST_COMMENT", "false").lower() == "true":
        post_review_comment(pull_request, result)
    else:
        # Print the review locally
        for file_review in result['file_reviews']:
            print(f"\n## {file_review['filename']}")
            print(file_review['review'])

if __name__ == "__main__":
    main()